﻿using Astral.Quester.Classes;
using MyNW.Internals;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EntityPlugin.Conditions
{
    public class PlayerParagon : Condition
    {

        public List<string> PlayerParagons = new List<string>();

        public override bool IsValid
        {
            get
            {
                return PlayerParagons.Contains(EntityManager.LocalPlayer.Character?.CurrentPowerTreeBuild?.SecondaryPaths?.FirstOrDefault()?.Path?.PowerTree?.Name);
            //switch (EntityManager.LocalPlayer.Character.CurrentPowerTreeBuild.SecondaryPaths.FirstOrDefault()?.Path.PowerTree.Name)
            //{
            //    case "Paragon_Masterofflame":
            //        return ParagonCategory.CW_Masterofflame;

                //    case "Paragon_Spellstormmage":
                //        return ParagonCategory.CW_Spellstormmage;

                //    case "Paragon_Divineoracle":
                //        return ParagonCategory.DC_Divineoracle;

                //    case "Paragon_Anointedchampion":
                //        return ParagonCategory.DC_Anointedchampion;

                //    case "Paragon_Swordmaster":
                //        return ParagonCategory.GW_Swordmaster;

                //    case "Paragon_Ironvanguard_Gwf":
                //        return ParagonCategory.GW_Ironvanguard;

                //    case "Paragon_Swordmaster_Gf":
                //        return ParagonCategory.GF_Swordmaster;

                //    case "Paragon_Ironvanguard":
                //        return ParagonCategory.GF_Ironvanguard;

                //    case "Paragon_Stormwarden":
                //        return ParagonCategory.HR_Stormwarden;

                //    case "Paragon_Pathfinder":
                //        return ParagonCategory.HR_Pathfinder;

                //    case "Paragon_Oathofdevotion":
                //        return ParagonCategory.OP_Oathofdevotion;

                //    case "Paragon_Oathofprotection":
                //        return ParagonCategory.OP_Oathofprotection;

                //    case "Paragon_Hellbringer":
                //        return ParagonCategory.SW_Hellbringer;

                //    case "Paragon_Soulbinder":
                //        return ParagonCategory.SW_Soulbinder;

                //    case "Paragon_Whisperknife":
                //        return ParagonCategory.TR_Whisperknife;

                //    case "Paragon_Masterinfiltrator":
                //        return ParagonCategory.TR_Masterinfiltrator;

                //    default:
                //        return ParagonCategory.Unknown;
                //}
            }
        }

        public override void Reset() { }
    }
}
