﻿using MyNW.Classes;
using MyNW.Internals;
using MyNW.Patchables.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Astral.Classes.ItemFilter;
using EntityTools.Enums;
using System.Collections;
using System.Collections.ObjectModel;
using static EntityTools.Tools.BuySellItems.BuyFilterEntry;
using EntityTools.Reflection;
using System.Xml.Serialization;
using System.ComponentModel;

namespace EntityTools.Tools.BuySellItems
{
    /// <summary>
    /// Индексированная сумка
    /// Реализация логики KeyedCollection и перечисления
    /// </summary>
    public partial class IndexedBags<TFilterEntry> : KeyedCollection<TFilterEntry, SlotCache<TFilterEntry>>, IEnumerable<SlotCache<TFilterEntry>>
    {
        protected override TFilterEntry GetKeyForItem(SlotCache<TFilterEntry> slotCache)
        {
            return slotCache.Filter;
        }

        new public SlotCache<TFilterEntry> this[TFilterEntry fItem]
        {
            get
            {
                if (base.Count == 0 && _filters.IsValid)
                    Indexing();

                if (base.Contains(fItem))
                    return base[fItem].AsReadOnly();

                return emptySlotCache;
            }
        }

#if disabled_20200614_1006
        // Указанный функционал реализован в GetEnumerator()
        /// <summary>
        /// Индекс слотов сумки по фильтру
        /// </summary>
        public IEnumerable<SlotCache<TFilterEntry>> FilteredSlots
        {
            get
            {
                if (base.Count == 0)
                    Indexing();

                using (var enumer = base.GetEnumerator())
                {
                    while (enumer.MoveNext())
                        yield return enumer.Current;
                }
            }
        } 
#endif

        new public IEnumerator<SlotCache<TFilterEntry>> GetEnumerator()
        {
            if (base.Count == 0)
                Indexing();

            return base.GetEnumerator();
        }
    }

    /// <summary>
    /// Индексированная сумка
    /// Реализация логики индексирования
    /// </summary>
    /// <typeparam name="TFilterEntry"></typeparam>
    public partial class IndexedBags<TFilterEntry> where TFilterEntry : IFilterEntry
    {
        public IndexedBags() { }
        public IndexedBags(ItemFilterCoreExt<TFilterEntry> filters)
        {
            _filters = CopyHelper.CreateDeepCopy(filters);
        }
        public IndexedBags(ItemFilterCoreExt<TFilterEntry> filters, BagsList bags)
        {
            _filters = CopyHelper.CreateDeepCopy(filters);
            _bags = CopyHelper.CreateDeepCopy(bags);
        }
        public IndexedBags(ItemFilterCoreExt<TFilterEntry> filters, InvBagIDs[] bagsIds)
        {
            _filters = CopyHelper.CreateDeepCopy(filters);
            _bags = new BagsList(bagsIds);
        }

        /// <summary>
        /// Список фильтров
        /// </summary>
        public ItemFilterCoreExt<TFilterEntry> Filters { get => _filters;
            set
            {
                if(_filters != value)
                {
                    _filters = value;
                    Clear();
                }
            }
        }
        public ItemFilterCoreExt<TFilterEntry> _filters;

        /// <summary>
        /// Список-заглушка, возвращаемые при отсутствии содержимого в сумке
        /// </summary>
        static readonly SlotCache<TFilterEntry> emptySlotCache = new SlotCache<TFilterEntry>((TFilterEntry)Activator.CreateInstance(typeof(TFilterEntry)), true);

        /// <summary>
        /// Список индексированных сумок
        /// </summary>
        BagsList Bags
        {
            get => _bags;
        }
        BagsList _bags = new BagsList();

        /// <summary>
        /// Формирование описания индексированого содержимого сумки
        /// </summary>
        /// <param name="type"></param>
        /// <param name="slots"></param>
        /// <returns></returns>
        public string Description()
        {
            StringBuilder sb = new StringBuilder();

            {
                if (_filters.IsValid && (base.Count == 0))
                    Indexing();

                if (base.Count > 0)
                {
                    using (var enumer = base.GetEnumerator())
                    {
                        if (enumer.MoveNext())
                        {
                            var cachedSlots = enumer.Current;
                            if (cachedSlots.Count > 0)
                            {
                                sb.Append(cachedSlots.Filter.ToString()).AppendLine(" matches to:");
                                foreach (var slot in cachedSlots)
                                {
                                    sb.Append('\t').Append(slot.Item.ItemDef.DisplayName).Append('[').Append(slot.Item.ItemDef.InternalName).Append("] {");
                                    int catNum = 0;
                                    foreach (var cat in slot.Item.ItemDef.Categories)
                                    {
                                        if (catNum > 0) sb.Append(", ");
                                        sb.Append(cat);
                                        catNum++;
                                    }
                                    sb.AppendLine("}");
                                    sb.Append("\tMaxItemLevel: ").AppendLine(cachedSlots.MaxItemLevel.ToString());
                                    sb.Append("\tTotalItemsCount: ").AppendLine(cachedSlots.TotalItemsCount.ToString());
                                }
                            }
                        }
                    }
                }
                else sb.AppendLine("No item matches");
            }
            return sb.ToString();
        }

        /// <summary>
        /// Анализ сумок, заданных в Bags и индексирование их содержимого.
        /// </summary>
        /// <param name="slots"></param>
        private void Indexing()
        {
            base.ClearItems();
            if (_filters.IsValid)
            {
                // Перебираем сумки
                foreach (var bag in _bags.GetSelectedBags())
                {
                    // Перебираем содержимое сумок
                    foreach (var slot in bag.GetItems)
                    {
                        // Прроверяем слот на соответствие запрещающему фильтру
                        if(!_filters.IsForbidden(slot))
                        {
                            // Проверяем слот на соответствие разрешающим фильтрам
                            foreach (var filter in _filters.IncludeFilters)
                            {
                                if(filter.IsMatch(slot))
                                {
                                    // Помещаем слот в индексированную коллекцию
                                    if (base.Contains(filter))
                                        base[filter].Add(slot);
                                    else base.Add(new SlotCache<TFilterEntry>(filter, slot));
                                }
                            }
                        }
                    }
                }
            }
        }    
    }
}
