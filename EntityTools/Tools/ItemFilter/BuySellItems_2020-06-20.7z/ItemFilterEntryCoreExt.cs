﻿using Astral.Classes.ItemFilter;
using EntityTools.Reflection;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Schema;
using System.Xml.Serialization;
using MyNW.Classes;

namespace EntityTools.Tools.BuySellItems
{
    /// <summary>
    /// Класс, реализующий набор фильтров и логику проверки соответствия
    /// </summary>
    /// <typeparam name="TFilterEntry"></typeparam>
    [Serializable]
    public partial class ItemFilterCoreExt<TFilterEntry> where TFilterEntry : IFilterEntry
    {
        public ItemFilterCoreExt()
        {
            _fullFilters.ListChanged += ResetPredicates;
        }
        /// <summary>
        /// Конструктор копирования
        /// </summary>
        /// <param name="source"></param>
        public ItemFilterCoreExt(ItemFilterCoreExt<TFilterEntry> source)
        {
            if (source != null && source._fullFilters != null && source._fullFilters.Count > 0)
            {
                foreach (var f in source._fullFilters)
                    _fullFilters.Add((TFilterEntry)f.Clone());
                isMatchPredicate = IsMatch_Selector;
                excludePredicate = IsForbidden_Selector;
            }
            _fullFilters.ListChanged += ResetPredicates;
        }
        /// <summary>
        /// Полный список фильтров без разделения на Include/Exclude
        /// </summary>
        public BindingList<TFilterEntry> Filters
        {
            get => _fullFilters;
            set
            {
                if (value != null && value.Count > 0)
                {
                    _fullFilters.ListChanged -= ResetPredicates;
#if disabled_20200616_1358
                    // Разделение include-фильтра и формирование запрещающего предиката
                    AnalizeFilters(value, out _includes, out excludePredicate); 
#else
                    // Инициируем отложенный анализ фильтров 
                    if (_includes != null) _includes.Clear();
                    isMatchPredicate = IsMatch_Selector;
                    excludePredicate = IsForbidden_Selector;
#endif
                    _fullFilters = value;
                    _fullFilters.ListChanged += ResetPredicates;
                }
                else
                {
                    _fullFilters.ListChanged -= ResetPredicates;
                    if(_includes != null) _includes.Clear();
                    isMatchPredicate = IsMatch_Selector;
                    excludePredicate = IsForbidden_Selector;
                    _fullFilters.Clear();
                }
            } 
        }
        [XmlIgnore]
        BindingList<TFilterEntry> _fullFilters = new BindingList<TFilterEntry>();

        /// <summary>
        /// список Include-Фильтров
        /// </summary>
        public IList<TFilterEntry> IncludeFilters
        {
            get
            {
                if (_includes != null)
                    return _includes.AsReadOnly();
                else if (_fullFilters != null)
                {
                    AnalizeFilters(_fullFilters, out _includes, out excludePredicate);
                    if (_includes is null)
                        return _emptyList;
                    else return _includes;
                }
                else return _emptyList;
            }
        }
        [XmlIgnore]
        List<TFilterEntry> _includes = new List<TFilterEntry>();
        readonly IList<TFilterEntry> _emptyList = new List<TFilterEntry>().AsReadOnly();

        public bool IsValid
        {
            get => _fullFilters != null && _fullFilters.Count > 0 && isMatchPredicate != null;
        }

        /// <summary>
        /// Выделение из списка фильтров <seealso cref="Filters"/> разрешающих (include) фильтров <seealso cref="IncludeFilters"/> и формирование запрещающего предиката <seealso cref="excludePredicate"/>
        /// </summary>
        /// <param name="inFilters"></param>
        /// <param name="outIncludes"></param>
        /// <param name="outExclude"></param>
        private bool AnalizeFilters(IEnumerable<TFilterEntry> inFilters, out List<TFilterEntry> outIncludes, out Predicate<Item> outExclude)
        {
            if (inFilters != null)
            {
                outIncludes = new List<TFilterEntry>();

                outExclude = null;

                // вставка с одновременной сортировкой по возрастанию Priority
                foreach (var f in inFilters)
                {
                    if (f.Mode == ItemFilterMode.Include)
                    {
                        outIncludes.Add((TFilterEntry)f.AsReadOnly());
                    }
                    else if (outExclude is null) outExclude = f.AsReadOnly().IsMatch;
                    else outExclude += f.AsReadOnly().IsMatch;
                    f.PropertyChanged += ResetPredicates;
                }
                return true;
            }
            outIncludes = null;
            outExclude = null;
            return false;
        }
        /// <summary>
        /// Выделение из списка фильтров <seealso cref="Filters"/> разрешающих (include) фильтров <seealso cref="IncludeFilters"/> и формирование запрещающего предиката <seealso cref="excludePredicate"/>
        /// </summary>
        /// <param name="inFilters"></param>
        /// <param name="outIncludes"></param>
        /// <param name="outExclude"></param>
        private bool AnalizeFilters(IEnumerable<BuyFilterEntry> inFilters, out List<BuyFilterEntry> outIncludes, out Predicate<Item> outExclude)
        {
            if (inFilters != null)
            {
                outIncludes = new List<BuyFilterEntry>();

                outExclude = null;

                // вставка с одновременной сортировкой по возрастанию Priority
                foreach (BuyFilterEntry f in inFilters.OrderBy(fe => fe.Priority))
                {
                    if (f.Mode == ItemFilterMode.Include)
                    {
                        outIncludes.Add((BuyFilterEntry)f.AsReadOnly());
                    }
                    else if (outExclude is null) outExclude = f.AsReadOnly().IsMatch;
                    else outExclude += f.AsReadOnly().IsMatch;
                    f.PropertyChanged += ResetPredicates;
                }
                return true;
            }
            outIncludes = null;
            outExclude = null;
            return false;
        }

#if event_PropertyChanged
        /// <summary>
        /// Делегат, реализующий обнуление предикатов <seealso cref="isMatchPredicate"/> и <seealso cref="excludePredicate"/> в случае изменения свойств элементов списка фильтров <seealso cref="Filters"/>
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ResetPredicates(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(IFilterEntry.EntryType)
                || e.PropertyName == nameof(IFilterEntry.Mode)
                || e.PropertyName == nameof(IFilterEntry.Pattern)
                || e.PropertyName == nameof(BuyFilterEntry.Priority))
            {
                _includes = null;
                excludePredicate = null;
                isMatchPredicate = IsMatch_Selector;
            }
        }
#else
        /// <summary>
        /// Делегат, реализующий обнуление предикатов <seealso cref="isMatchPredicate"/> и <seealso cref="excludePredicate"/> в случае изменения свойств элементов списка фильтров <seealso cref="Filters"/>
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ResetPredicates(object sender, string propertyName)
        {
            if (propertyName == nameof(IFilterEntry.EntryType)
                || propertyName == nameof(IFilterEntry.Mode)
                || propertyName == nameof(IFilterEntry.Pattern)
                || propertyName == nameof(BuyFilterEntry.Priority))
            {
                if (_includes != null) _includes.Clear();
                excludePredicate = IsForbidden_Selector;
                isMatchPredicate = IsMatch_Selector;
            }
        }
#endif
        /// <summary>
        /// Делегат, реализующий обнуление предикатов <seealso cref="isMatchPredicate"/> и <seealso cref="excludePredicate"/> сопоставления в случае изменения списка <seealso cref="Filters"/> (добавление, удаление, изменение)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ResetPredicates(object sender, ListChangedEventArgs e)
        {
            if (e.ListChangedType == ListChangedType.ItemAdded
               || e.ListChangedType == ListChangedType.ItemChanged
               || e.ListChangedType == ListChangedType.ItemDeleted)
            {
                if (_includes != null) _includes.Clear();
                excludePredicate = IsForbidden_Selector;
                isMatchPredicate = IsMatch_Selector;
            }
        }

        #region Сопоставление
        /// <summary>
        /// Функтор сопоставления, выполняющий проверку include и exclude фильтров
        /// </summary>
        Predicate<Item> isMatchPredicate = null;

        /// <summary>
        /// Запрещающий предикат, исключающий Item из обработки
        /// </summary>
        [XmlIgnore]
        Predicate<Item> excludePredicate = null;

        /// <summary>
        /// Проверка слота на соответствие набору фильтров, включая проверку include и exclude фильтров
        /// </summary>
        /// <param name="slot"></param>
        /// <returns></returns>
        public bool IsMatch(InventorySlot slot)
        {
            return IsMatch(slot.Item);
        }
        public bool IsMatch(Item item)
        {
            return isMatchPredicate.Invoke(item) == true;
        }

        /// <summary>
        /// Проверка слота на соответствие запрещающему Exclude-фильтру
        /// </summary>
        /// <param name="slot"></param>
        /// <returns></returns>
        public bool IsForbidden(InventorySlot slot)
        {
            return excludePredicate?.Invoke(slot.Item) == true;
        }
        public bool IsForbidden(Item item)
        {
            return excludePredicate?.Invoke(item) == true;
        }
        /// <summary>
        /// Конструирование 
        /// </summary>
        /// <param name="item"></param>
        /// <returns></returns>
        bool IsForbidden_Selector(Item item)
        {
            if (_fullFilters != null && _fullFilters.Count > 0)
            {
                if (_includes is null || _includes.Count == 0)
                {
                    AnalizeFilters(_fullFilters, out _includes, out Predicate<Item> exclude);
                    if (exclude != null)
                    {
                        excludePredicate = exclude;
                        excludePredicate(item);
                    }
                    else
                    {
                        excludePredicate = IsForbidden_False;
                        return false;
                    }
                }
                else excludePredicate = IsForbidden_False;
            }
            excludePredicate = IsForbidden_True;
            return true;
        }
        bool IsForbidden_True(Item item)
        {
            return true;
        }
        bool IsForbidden_False(Item item)
        {
            return false;
        }

        /// <summary>
        /// Конструирование функтора сопоставления
        /// </summary>
        /// <param name="item"></param>
        /// <returns></returns>
        bool IsMatch_Selector(Item item)
        {
            if (_fullFilters != null && _fullFilters.Count > 0)
            {
                // Анализ фильтров
                AnalizeFilters(_fullFilters, out _includes, out Predicate<Item> exclude);

                // Выбор предиката
                if (exclude is null)
                {
                    if (_includes is null || _includes.Count == 0)
                        isMatchPredicate = IsMatch_False;
                    else isMatchPredicate = IsMatch_IncludeFilter;
                    excludePredicate = IsForbidden_False;
                }
                else
                {
                    if (_includes is null || _includes.Count == 0)
                        isMatchPredicate = IsMatch_ExcludeFilter;
                    else isMatchPredicate = IsMatch_IncludeExcludeFilter;
                    excludePredicate = exclude;
                }
            }
            else
            {
                isMatchPredicate = IsMatch_False;
                excludePredicate = IsForbidden_True;
            }
            return isMatchPredicate(item);
        }

        /// <summary>
        /// Соспоставление с Include и Exclude фильтрами
        /// </summary>
        bool IsMatch_IncludeExcludeFilter(Item item)
        {
            // Сопоставляем все слоты с фильтрами
            foreach (IFilterEntry f in _includes)
                if (!excludePredicate(item) && f.IsMatch(item))
                    return true;
            return false;
        }
        /// <summary>
        /// Соспоставление с Include фильтрами
        /// </summary>
        /// <param name="slots"></param>
        bool IsMatch_IncludeFilter(Item item)
        {
            foreach (IFilterEntry f in _includes)
                if (f.IsMatch(item))
                    return true;
            return false;
        }
        /// <summary>
        /// Соспоставление с Exclude фильтрами
        /// </summary>
        bool IsMatch_ExcludeFilter(Item item)
        {
            return !excludePredicate(item);
        }
        /// <summary>
        /// Заглушка при отсутствии фильтров
        /// </summary>
        bool IsMatch_False(Item item)
        {
            return false;
        }
        #endregion

        public override string ToString()
        {
            if (_fullFilters != null && _fullFilters.Count > 0)
                return $"{_fullFilters.Count} entries in filter";
            else return "Filter is empty";
        }
    }

    // Часть определения класса, реализующего интерфейсы
    public partial class ItemFilterCoreExt<TFilterEntry> : IXmlSerializable, IEnumerable<TFilterEntry>
    {
        #region IXmlSerializable
        public XmlSchema GetSchema()
        {
            return null;
        }

        public void ReadXml(XmlReader reader)
        {
            if (reader.IsStartElement())
            {
                string elemName = reader.Name;
                {
                    if (reader.IsEmptyElement)
                    {
                        reader.ReadStartElement(elemName);
                    }
                    else
                    {
                        reader.ReadStartElement(elemName);
                        ReadInnerXml(reader, elemName);
                        reader.ReadEndElement();
                    }
                }
            }
        }

        /// <summary>
        ///  Рекурсивное считывание поддерева xml до обнаружения xmlEndElement
        /// </summary>
        /// <param name="reader"></param>
        /// <param name="xmlEndElement"></param>
        private void ReadInnerXml(XmlReader reader, string xmlEndElement)
        {
            while (reader.ReadState == ReadState.Interactive)
            {
                string elemName = reader.Name;
                if (elemName == nameof(ItemFilterCore.Entries))
                {
                    if (reader.IsEmptyElement)
                    {
                        reader.ReadStartElement(elemName);
                        return;
                    }
                    else if (reader.IsStartElement())
                    {
                        reader.ReadStartElement(elemName);
                        ReadInnerXml(reader, elemName);
                        reader.ReadEndElement();
                    }
                    else return;
                }
                else if (reader.IsStartElement() 
                          && (elemName == nameof(ItemFilterEntry)
                              || elemName == nameof(CommonFilterEntry)
                              || elemName == nameof(BuyFilterEntry)
                              || elemName == "ItemFilterEntryExt"))
                {
                    TFilterEntry filterEntry = (TFilterEntry)Activator.CreateInstance(typeof(TFilterEntry));
                    filterEntry.ReadXml(reader);
                    _fullFilters.Add(filterEntry);
                }
                else if (elemName == xmlEndElement)
                {
                    if (!reader.IsStartElement())
                        return;
                    else throw new XmlException($"{MethodBase.GetCurrentMethod().Name}: Unexpected XmlStartElement '{elemName}' while there are should be the XmlEndElement '{xmlEndElement}'");
                }
                else reader.Skip();
            }
        }

        public void WriteXml(XmlWriter writer)
        {
            foreach(TFilterEntry fEntry in _fullFilters)
            {
                writer.WriteStartElement(fEntry.GetType().Name, "");
                fEntry.WriteXml(writer);
                writer.WriteEndElement();
            }
        }
        #endregion

        #region IEnumerable
        public IEnumerator<TFilterEntry> GetEnumerator()
        {
            if (_fullFilters != null && _fullFilters.Count > 0)
                return _fullFilters.GetEnumerator();
            return null;
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            if (_fullFilters != null && _fullFilters.Count > 0)
                return _fullFilters.GetEnumerator();
            return null;
        } 
        #endregion
    }
}
