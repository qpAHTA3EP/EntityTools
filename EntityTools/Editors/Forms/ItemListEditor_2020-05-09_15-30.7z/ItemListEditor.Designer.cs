﻿using Astral.Classes.ItemFilter;
using DevExpress.XtraBars;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Controls;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraGrid;
using DevExpress.XtraGrid.Columns;
using DevExpress.XtraGrid.Views.Base;
using DevExpress.XtraGrid.Views.Grid;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace EntityTools.Editors
{
    partial class ItemListEditor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            DevExpress.XtraGrid.GridLevelNode gridLevelNode1 = new DevExpress.XtraGrid.GridLevelNode();
            DevExpress.XtraGrid.GridLevelNode gridLevelNode2 = new DevExpress.XtraGrid.GridLevelNode();
            this.purchaseOptions = new DevExpress.XtraGrid.GridControl();
            this.bindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gridView = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colStringType = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colEntryType = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colMode = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colText = new DevExpress.XtraGrid.Columns.GridColumn();
            this.bRemoveEntry = new DevExpress.XtraEditors.SimpleButton();
            this.bAddEntry = new DevExpress.XtraEditors.DropDownButton();
            this.addEntryPop = new DevExpress.XtraBars.PopupControlContainer(this.components);
            this.btnReverse = new DevExpress.XtraEditors.CheckButton();
            this.btnAddItem = new DevExpress.XtraEditors.SimpleButton();
            this.addTypeLabel = new DevExpress.XtraEditors.LabelControl();
            this.itemListCombo = new DevExpress.XtraEditors.ComboBoxEdit();
            this.barManager = new DevExpress.XtraBars.BarManager(this.components);
            this.barDockControl_0 = new DevExpress.XtraBars.BarDockControl();
            this.barDockControl_1 = new DevExpress.XtraBars.BarDockControl();
            this.barDockControl_2 = new DevExpress.XtraBars.BarDockControl();
            this.barDockControl_3 = new DevExpress.XtraBars.BarDockControl();
            this.barButtonItem1 = new DevExpress.XtraBars.BarButtonItem();
            this.barEditItem = new DevExpress.XtraBars.BarEditItem();
            this.fastAddItemCombo = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.barListItem = new DevExpress.XtraBars.BarListItem();
            this.barToolbarsListItem = new DevExpress.XtraBars.BarToolbarsListItem();
            this.bAddEntryAdvanced = new DevExpress.XtraEditors.SimpleButton();
            this.addEntryMenu = new DevExpress.XtraBars.PopupMenu(this.components);
            this.btnShowItems = new DevExpress.XtraEditors.SimpleButton();
            this.btnClear = new DevExpress.XtraEditors.SimpleButton();
            this.btnExport = new DevExpress.XtraEditors.SimpleButton();
            this.btnImport = new DevExpress.XtraEditors.SimpleButton();
            this.colCount = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colCheckEquipmentLevel = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colCheckPlayerLevel = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colPutOnItem = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colOverallNumber = new DevExpress.XtraGrid.Columns.GridColumn();
            this.btnCancel = new DevExpress.XtraEditors.SimpleButton();
            this.bntSave = new DevExpress.XtraEditors.SimpleButton();
            ((System.ComponentModel.ISupportInitialize)(this.purchaseOptions)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.addEntryPop)).BeginInit();
            this.addEntryPop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.itemListCombo.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.barManager)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fastAddItemCombo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.addEntryMenu)).BeginInit();
            this.SuspendLayout();
            // 
            // purchaseOptions
            // 
            this.purchaseOptions.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.purchaseOptions.Cursor = System.Windows.Forms.Cursors.Default;
            this.purchaseOptions.DataSource = this.bindingSource;
            gridLevelNode1.RelationName = "Level1";
            gridLevelNode2.RelationName = "Level2";
            this.purchaseOptions.LevelTree.Nodes.AddRange(new DevExpress.XtraGrid.GridLevelNode[] {
            gridLevelNode1,
            gridLevelNode2});
            this.purchaseOptions.Location = new System.Drawing.Point(12, 12);
            this.purchaseOptions.MainView = this.gridView;
            this.purchaseOptions.Name = "purchaseOptions";
            this.purchaseOptions.Size = new System.Drawing.Size(806, 374);
            this.purchaseOptions.TabIndex = 6;
            this.purchaseOptions.UseEmbeddedNavigator = true;
            this.purchaseOptions.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView});
            // 
            // gridView
            // 
            this.gridView.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colStringType,
            this.colEntryType,
            this.colMode,
            this.colText,
            this.colCount,
            this.colCheckEquipmentLevel,
            this.colCheckPlayerLevel,
            this.colOverallNumber,
            this.colPutOnItem});
            this.gridView.GridControl = this.purchaseOptions;
            this.gridView.Name = "gridView";
            this.gridView.OptionsView.ShowGroupPanel = false;
            this.gridView.OptionsView.ShowIndicator = false;
            // 
            // colStringType
            // 
            this.colStringType.Caption = "Text type";
            this.colStringType.FieldName = "StringType";
            this.colStringType.Name = "colStringType";
            this.colStringType.OptionsColumn.AllowSize = false;
            this.colStringType.OptionsColumn.FixedWidth = true;
            this.colStringType.Visible = true;
            this.colStringType.VisibleIndex = 0;
            // 
            // colEntryType
            // 
            this.colEntryType.Caption = "Filter type";
            this.colEntryType.FieldName = "EntryType";
            this.colEntryType.Name = "colEntryType";
            this.colEntryType.OptionsColumn.AllowSize = false;
            this.colEntryType.OptionsColumn.FixedWidth = true;
            this.colEntryType.Visible = true;
            this.colEntryType.VisibleIndex = 1;
            // 
            // colMode
            // 
            this.colMode.Caption = "Inclusion";
            this.colMode.FieldName = "Mode";
            this.colMode.Name = "colMode";
            this.colMode.OptionsColumn.AllowSize = false;
            this.colMode.OptionsColumn.FixedWidth = true;
            this.colMode.Visible = true;
            this.colMode.VisibleIndex = 2;
            // 
            // colText
            // 
            this.colText.FieldName = "Identifier";
            this.colText.Name = "colText";
            this.colText.Visible = true;
            this.colText.VisibleIndex = 3;
            this.colText.Width = 400;
            // 
            // bRemoveEntry
            // 
            this.bRemoveEntry.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.bRemoveEntry.Location = new System.Drawing.Point(337, 395);
            this.bRemoveEntry.Name = "bRemoveEntry";
            this.bRemoveEntry.Size = new System.Drawing.Size(99, 23);
            this.bRemoveEntry.TabIndex = 8;
            this.bRemoveEntry.Text = "Remove selected";
            // 
            // bAddEntry
            // 
            this.bAddEntry.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.bAddEntry.DropDownArrowStyle = DevExpress.XtraEditors.DropDownArrowStyle.Show;
            this.bAddEntry.DropDownControl = this.addEntryPop;
            this.bAddEntry.Location = new System.Drawing.Point(12, 395);
            this.bAddEntry.Name = "bAddEntry";
            this.bAddEntry.Size = new System.Drawing.Size(135, 23);
            this.bAddEntry.TabIndex = 9;
            this.bAddEntry.Text = "Add entry to filter";
            // 
            // addEntryPop
            // 
            this.addEntryPop.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.addEntryPop.Controls.Add(this.btnReverse);
            this.addEntryPop.Controls.Add(this.btnAddItem);
            this.addEntryPop.Controls.Add(this.addTypeLabel);
            this.addEntryPop.Controls.Add(this.itemListCombo);
            this.addEntryPop.Controls.Add(this.bAddEntryAdvanced);
            this.addEntryPop.Location = new System.Drawing.Point(47, 223);
            this.addEntryPop.Manager = this.barManager;
            this.addEntryPop.Name = "addEntryPop";
            this.addEntryPop.Size = new System.Drawing.Size(319, 90);
            this.addEntryPop.TabIndex = 14;
            this.addEntryPop.Visible = false;
            // 
            // bReverse
            // 
            this.btnReverse.ImageOptions.Image = global::EntityTools.Properties.Resources.miniReverse;
            this.btnReverse.ImageOptions.Location = DevExpress.XtraEditors.ImageLocation.MiddleCenter;
            this.btnReverse.Location = new System.Drawing.Point(278, 14);
            this.btnReverse.Name = "bReverse";
            this.btnReverse.Size = new System.Drawing.Size(24, 23);
            this.btnReverse.TabIndex = 13;
            this.btnReverse.ToolTip = "Enable to sort list by display name";
            // 
            // bAddItem
            // 
            this.btnAddItem.ImageOptions.Image = global::EntityTools.Properties.Resources.miniAdd;
            this.btnAddItem.Location = new System.Drawing.Point(173, 47);
            this.btnAddItem.Name = "bAddItem";
            this.btnAddItem.Size = new System.Drawing.Size(75, 23);
            this.btnAddItem.TabIndex = 3;
            this.btnAddItem.Text = "Add";
            // 
            // addTypeLabel
            // 
            this.addTypeLabel.Location = new System.Drawing.Point(15, 19);
            this.addTypeLabel.Name = "addTypeLabel";
            this.addTypeLabel.Size = new System.Drawing.Size(49, 13);
            this.addTypeLabel.TabIndex = 2;
            this.addTypeLabel.Text = "Add item :";
            // 
            // itemListCombo
            // 
            this.itemListCombo.Location = new System.Drawing.Point(70, 16);
            this.itemListCombo.MenuManager = this.barManager;
            this.itemListCombo.Name = "itemListCombo";
            this.itemListCombo.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.itemListCombo.Properties.Sorted = true;
            this.itemListCombo.Size = new System.Drawing.Size(202, 20);
            this.itemListCombo.TabIndex = 1;
            this.itemListCombo.EditValueChanging += new DevExpress.XtraEditors.Controls.ChangingEventHandler(this.itemListCombo_EditValueChanging);
            // 
            // barManager
            // 
            this.barManager.DockControls.Add(this.barDockControl_0);
            this.barManager.DockControls.Add(this.barDockControl_1);
            this.barManager.DockControls.Add(this.barDockControl_2);
            this.barManager.DockControls.Add(this.barDockControl_3);
            this.barManager.Form = this;
            this.barManager.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.barButtonItem1,
            this.barEditItem,
            this.barListItem,
            this.barToolbarsListItem});
            this.barManager.MaxItemId = 4;
            this.barManager.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.fastAddItemCombo});
            // 
            // barDockControl_0
            // 
            this.barDockControl_0.CausesValidation = false;
            this.barDockControl_0.Dock = System.Windows.Forms.DockStyle.Top;
            this.barDockControl_0.Location = new System.Drawing.Point(0, 0);
            this.barDockControl_0.Manager = this.barManager;
            this.barDockControl_0.Size = new System.Drawing.Size(830, 0);
            // 
            // barDockControl_1
            // 
            this.barDockControl_1.CausesValidation = false;
            this.barDockControl_1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.barDockControl_1.Location = new System.Drawing.Point(0, 430);
            this.barDockControl_1.Manager = this.barManager;
            this.barDockControl_1.Size = new System.Drawing.Size(830, 0);
            // 
            // barDockControl_2
            // 
            this.barDockControl_2.CausesValidation = false;
            this.barDockControl_2.Dock = System.Windows.Forms.DockStyle.Left;
            this.barDockControl_2.Location = new System.Drawing.Point(0, 0);
            this.barDockControl_2.Manager = this.barManager;
            this.barDockControl_2.Size = new System.Drawing.Size(0, 430);
            // 
            // barDockControl_3
            // 
            this.barDockControl_3.CausesValidation = false;
            this.barDockControl_3.Dock = System.Windows.Forms.DockStyle.Right;
            this.barDockControl_3.Location = new System.Drawing.Point(830, 0);
            this.barDockControl_3.Manager = this.barManager;
            this.barDockControl_3.Size = new System.Drawing.Size(0, 430);
            // 
            // barButtonItem1
            // 
            this.barButtonItem1.Caption = "Advanced";
            this.barButtonItem1.Id = 0;
            this.barButtonItem1.Name = "barButtonItem1";
            // 
            // barEditItem1
            // 
            this.barEditItem.Caption = "Add an item";
            this.barEditItem.Edit = this.fastAddItemCombo;
            this.barEditItem.Id = 1;
            this.barEditItem.Name = "barEditItem1";
            // 
            // fastAddItemCombo
            // 
            this.fastAddItemCombo.AutoHeight = false;
            this.fastAddItemCombo.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.fastAddItemCombo.Items.AddRange(new object[] {
            "fgrte",
            "gfdg",
            "trterg"});
            this.fastAddItemCombo.Name = "fastAddItemCombo";
            this.fastAddItemCombo.Sorted = true;
            // 
            // barListItem1
            // 
            this.barListItem.Caption = "Test";
            this.barListItem.Id = 2;
            this.barListItem.Name = "barListItem1";
            this.barListItem.Strings.AddRange(new object[] {
            "uytru",
            "yturtyut",
            "ghjfghj",
            "turty",
            "jhgfitj"});
            // 
            // barToolbarsListItem1
            // 
            this.barToolbarsListItem.Caption = "test";
            this.barToolbarsListItem.Id = 3;
            this.barToolbarsListItem.Name = "barToolbarsListItem1";
            // 
            // bAddEntryAdvanced
            // 
            this.bAddEntryAdvanced.Location = new System.Drawing.Point(72, 47);
            this.bAddEntryAdvanced.Name = "bAddEntryAdvanced";
            this.bAddEntryAdvanced.Size = new System.Drawing.Size(75, 23);
            this.bAddEntryAdvanced.TabIndex = 0;
            this.bAddEntryAdvanced.Text = "Advanced...";
            // 
            // addEntryMenu
            // 
            this.addEntryMenu.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem1)});
            this.addEntryMenu.Manager = this.barManager;
            this.addEntryMenu.MinWidth = 300;
            this.addEntryMenu.Name = "addEntryMenu";
            // 
            // bShowItems
            // 
            this.btnShowItems.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnShowItems.Location = new System.Drawing.Point(153, 395);
            this.btnShowItems.Name = "bShowItems";
            this.btnShowItems.Size = new System.Drawing.Size(91, 23);
            this.btnShowItems.TabIndex = 19;
            this.btnShowItems.Text = "Show items";
            // 
            // bClear
            // 
            this.btnClear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnClear.ImageOptions.Image = global::EntityTools.Properties.Resources.miniDelete;
            this.btnClear.Location = new System.Drawing.Point(308, 395);
            this.btnClear.Name = "bClear";
            this.btnClear.Size = new System.Drawing.Size(23, 23);
            this.btnClear.TabIndex = 24;
            this.btnClear.ToolTip = "Clear list";
            // 
            // bExport
            // 
            this.btnExport.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnExport.ImageOptions.Image = global::EntityTools.Properties.Resources.miniExport;
            this.btnExport.Location = new System.Drawing.Point(279, 395);
            this.btnExport.Name = "bExport";
            this.btnExport.Size = new System.Drawing.Size(23, 23);
            this.btnExport.TabIndex = 29;
            this.btnExport.ToolTip = "Export";
            // 
            // bImport
            // 
            this.btnImport.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnImport.ImageOptions.Image = global::EntityTools.Properties.Resources.miniImport;
            this.btnImport.Location = new System.Drawing.Point(250, 395);
            this.btnImport.Name = "bImport";
            this.btnImport.Size = new System.Drawing.Size(23, 23);
            this.btnImport.TabIndex = 30;
            this.btnImport.ToolTip = "Import";
            // 
            // colCount
            // 
            this.colCount.Caption = "Count";
            this.colCount.DisplayFormat.FormatString = "N0";
            this.colCount.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.colCount.FieldName = "Count";
            this.colCount.Name = "colCount";
            this.colCount.UnboundType = DevExpress.Data.UnboundColumnType.Integer;
            this.colCount.Visible = true;
            this.colCount.VisibleIndex = 4;
            this.colCount.Width = 67;
            // 
            // colCheckEquipmentLevel
            // 
            this.colCheckEquipmentLevel.Caption = "EqpLvl";
            this.colCheckEquipmentLevel.FieldName = "colCheckEquipmentLevel";
            this.colCheckEquipmentLevel.Name = "colCheckEquipmentLevel";
            this.colCheckEquipmentLevel.OptionsColumn.AllowSize = false;
            this.colCheckEquipmentLevel.ToolTip = "Check Equipment Level";
            this.colCheckEquipmentLevel.UnboundType = DevExpress.Data.UnboundColumnType.Boolean;
            this.colCheckEquipmentLevel.Visible = true;
            this.colCheckEquipmentLevel.VisibleIndex = 5;
            this.colCheckEquipmentLevel.Width = 29;
            // 
            // colCheckPlayerLevel
            // 
            this.colCheckPlayerLevel.Caption = "PlrLvl";
            this.colCheckPlayerLevel.FieldName = "CheckPlayerLevel";
            this.colCheckPlayerLevel.Name = "colCheckPlayerLevel";
            this.colCheckPlayerLevel.OptionsColumn.AllowSize = false;
            this.colCheckPlayerLevel.ToolTip = "Check Player Level";
            this.colCheckPlayerLevel.UnboundType = DevExpress.Data.UnboundColumnType.Boolean;
            this.colCheckPlayerLevel.Visible = true;
            this.colCheckPlayerLevel.VisibleIndex = 6;
            this.colCheckPlayerLevel.Width = 28;
            // 
            // colPutOnItem
            // 
            this.colPutOnItem.Caption = "PutOnItem";
            this.colPutOnItem.FieldName = "colPutOnItem";
            this.colPutOnItem.Name = "colPutOnItem";
            this.colPutOnItem.OptionsColumn.AllowSize = false;
            this.colPutOnItem.ToolTip = "Equip item arter buying";
            this.colPutOnItem.UnboundType = DevExpress.Data.UnboundColumnType.Boolean;
            this.colPutOnItem.Visible = true;
            this.colPutOnItem.VisibleIndex = 8;
            this.colPutOnItem.Width = 20;
            // 
            // colOverallNumber
            // 
            this.colOverallNumber.Caption = "Ovrll";
            this.colOverallNumber.FieldName = "OverallNumber";
            this.colOverallNumber.Name = "colOverallNumber";
            this.colOverallNumber.OptionsColumn.AllowShowHide = false;
            this.colOverallNumber.OptionsColumn.AllowSize = false;
            this.colOverallNumber.ToolTip = "Keep numper of item to Count";
            this.colOverallNumber.UnboundType = DevExpress.Data.UnboundColumnType.Boolean;
            this.colOverallNumber.Visible = true;
            this.colOverallNumber.VisibleIndex = 7;
            this.colOverallNumber.Width = 31;
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.Location = new System.Drawing.Point(744, 395);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(74, 23);
            this.btnCancel.TabIndex = 8;
            this.btnCancel.Text = "Cancel";
            // 
            // bntSave
            // 
            this.bntSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.bntSave.Location = new System.Drawing.Point(664, 395);
            this.bntSave.Name = "bntSave";
            this.bntSave.Size = new System.Drawing.Size(74, 23);
            this.bntSave.TabIndex = 8;
            this.bntSave.Text = "Cancel";
            // 
            // ItemListEditor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(830, 430);
            this.Controls.Add(this.btnImport);
            this.Controls.Add(this.btnExport);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnShowItems);
            this.Controls.Add(this.addEntryPop);
            this.Controls.Add(this.bAddEntry);
            this.Controls.Add(this.bntSave);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.bRemoveEntry);
            this.Controls.Add(this.purchaseOptions);
            this.Controls.Add(this.barDockControl_2);
            this.Controls.Add(this.barDockControl_3);
            this.Controls.Add(this.barDockControl_1);
            this.Controls.Add(this.barDockControl_0);
            this.Name = "ItemListEditor";
            this.Text = "ItemListEditor";
            ((System.ComponentModel.ISupportInitialize)(this.purchaseOptions)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.addEntryPop)).EndInit();
            this.addEntryPop.ResumeLayout(false);
            this.addEntryPop.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.itemListCombo.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.barManager)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fastAddItemCombo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.addEntryMenu)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion

        private ItemFilterCoreType itemFilterCoreType;
        private ItemFilterCore itemFilterCore;
        //private IContainer components;
        private GridControl purchaseOptions;
        private GridView gridView;
        private BindingSource bindingSource;
        private GridColumn colStringType;
        private GridColumn colEntryType;
        private GridColumn colMode;
        private GridColumn colText;
        private GridColumn colCount;
        private GridColumn colCheckEquipmentLevel;
        private GridColumn colCheckPlayerLevel;
        private GridColumn colOverallNumber;
        private GridColumn colPutOnItem;
        private SimpleButton bRemoveEntry;
        private DropDownButton bAddEntry;
        private PopupMenu addEntryMenu;
        private BarButtonItem barButtonItem1;
        private BarManager barManager;
        private BarDockControl barDockControl_0;
        private BarDockControl barDockControl_1;
        private BarDockControl barDockControl_2;
        private BarDockControl barDockControl_3;
        private BarEditItem barEditItem;
        private RepositoryItemComboBox fastAddItemCombo;
        private BarListItem barListItem;
        private PopupControlContainer addEntryPop;
        private LabelControl addTypeLabel;
        private ComboBoxEdit itemListCombo;
        private SimpleButton bAddEntryAdvanced;
        private BarToolbarsListItem barToolbarsListItem;
        private SimpleButton btnAddItem;
        private SimpleButton btnShowItems;
        private SimpleButton btnClear;
        private SimpleButton btnImport;
        private SimpleButton btnExport;
        private SimpleButton bntSave;
        private SimpleButton btnCancel;
        private CheckButton btnReverse;
    }
}