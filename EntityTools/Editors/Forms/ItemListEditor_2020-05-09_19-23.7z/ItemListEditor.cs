﻿using Astral.Classes.ItemFilter;
using Astral.Controllers;
using DevExpress.XtraBars;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Controls;
using DevExpress.XtraEditors.Repository;
using EntityTools.Enums;
using EntityTools.Tools.BuySellItems;
using MyNW.Classes;
using MyNW.Internals;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace EntityTools.Forms
{
    public partial class ItemListEditorForm : Form
    {
        static ItemListEditorForm @this;

        BindingList<ItemFilterEntryExt> filter = new BindingList<ItemFilterEntryExt>();
        
        private ItemListEditorForm()
        {
            InitializeComponent();

#if false
            RepositoryItemComboBox repositoryItemComboBox = new RepositoryItemComboBox();
            repositoryItemComboBox.QueryPopUp += this.method_0;
            repositoryItemComboBox.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
            this.btnReverse.Visible = false;
            this.colEntryType.ColumnEdit = repositoryItemComboBox; 
#endif
        }

        public static bool GUIRequiest(ref List<ItemFilterEntryExt> list)
        {
            if (@this == null)
                @this = new ItemListEditorForm();


            @this.filter.Clear();
            if (list != null)
                foreach(var f in list)
                    @this.filter.Add(f);

            @this.purchaseOptions.DataSource = @this.filter;

            if(@this.ShowDialog() == DialogResult.OK)
            {
                list = @this.filter.ToList();
                return true;
            }
            else return false;
        }

        private void method_0(object sender, CancelEventArgs e)
        {
#if false
            ComboBoxEdit comboBoxEdit = sender as ComboBoxEdit;
            comboBoxEdit.Properties.Items.Clear();
            foreach (ItemFilterType itemFilterType in ItemFilterCore.smethod_0(this.Type))
            {
                comboBoxEdit.Properties.Items.Add(itemFilterType);
            } 
#endif
        }

#if false
        public ItemFilterCoreType Type
        {
            get
            {
                return this.itemFilterCoreType;
            }
            set
            {
                this.itemFilterCoreType = value;
                this.btnReverse.Visible = (value == ItemFilterCoreType.ItemsID);
                ItemFilterCoreType itemFilterCoreType = this.itemFilterCoreType;
                if (itemFilterCoreType == ItemFilterCoreType.Items)
                {
                    this.addTypeLabel.Text = "Add item :";
                    return;
                }
                if (itemFilterCoreType != ItemFilterCoreType.Loots)
                {
                    return;
                }
                this.addTypeLabel.Text = "Add loot :";
            } 
        }
#endif

        private void bRemoveEntry_Click(object sender, EventArgs e)
        {
            if (this.bindingSource.Current != null && XtraMessageBox.Show("Are you sure to delete this entry ?","Delete entry?", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                this.bindingSource.RemoveCurrent();
            }
        }

#if false
        [Browsable(false)]
        public ItemFilterCore Filter
        {
            get
            {
                return this.itemFilterCore;
            }
            set
            {
                this.itemFilterCore = value;
                if (value != null)
                {
                    this.bindingSource.DataSource = value.Entries;
                    return;
                }
                this.bindingSource.DataSource = null;
            }
        } 
#endif

        private void itemListCombo_QueryPopUp(object sender, CancelEventArgs e)
        {
#if false
            this.itemListCombo.Properties.Items.Clear();
            switch (this.itemFilterCoreType)
            {
                case ItemFilterCoreType.Items:
                    this.itemListCombo.Properties.Items.AddRange(ItemFilterCore.smethod_2(ItemFilterType.ItemName, false).Values);
                    return;
                case ItemFilterCoreType.Loots:
                    this.itemListCombo.Properties.Items.AddRange(ItemFilterCore.smethod_2(ItemFilterType.Loot, false).Values);
                    return;
                case ItemFilterCoreType.ItemsID:
                    this.itemListCombo.Properties.Items.AddRange(ItemFilterCore.smethod_2(ItemFilterType.ItemID, this.btnReverse.Checked).Values);
                    return;
                default:
                    return;
            } 
#endif
        }

        private void bAddEntryAdvanced_Click(object sender, EventArgs e)
        {
#if false
            this.addEntryPop.HidePopup();
            ItemFilterEntry itemFilterEntry = ItemFilterAddEntry.smethod_0(this.itemFilterCoreType);
            if (itemFilterEntry != null)
            {
                this.bindingSource.Add(itemFilterEntry);
                this.bindingSource.Position = this.bindingSource.IndexOf(itemFilterEntry);
            } 
#endif
        }

        public void method_AddItemFilterEntry(ItemFilterEntry itemFilterEntry)
        {
#if false
            if (itemFilterEntry != null)
            {
                bindingSource.Add(itemFilterEntry);
                bindingSource.Position = bindingSource.IndexOf(itemFilterEntry);
            } 
#endif
        }

        private void bAddItem_Click(object sender, EventArgs e)
        {
#if false
            string text = this.itemListCombo.Text;
            if (text.Length > 0)
            {
                ItemFilterEntry itemFilterEntry = new ItemFilterEntry
                {
                    Text = text
                };
                switch (this.Type)
                {
                    case ItemFilterCoreType.Items:
                        itemFilterEntry.Type = ItemFilterType.ItemName;
                        break;
                    case ItemFilterCoreType.Loots:
                        itemFilterEntry.Type = ItemFilterType.Loot;
                        break;
                    case ItemFilterCoreType.ItemsID:
                        itemFilterEntry.Type = ItemFilterType.ItemID;
                        break;
                }
                this.method_AddItemFilterEntry(itemFilterEntry);
                return;
            }
            XtraMessageBox.Show("Item name is empty !"); 
#endif
        }

        private void bShowItems_Click(object sender, EventArgs e)
        {
#if false
            string text = string.Empty;
            List<string> list = new List<string>();
            foreach (InventorySlot inventorySlot in EntityManager.LocalPlayer.AllItems)
            {
                if (!list.Contains(inventorySlot.Item.ItemDef.DisplayName) && this.Filter.method_0(inventorySlot.Item))
                {
                    list.Add(inventorySlot.Item.ItemDef.DisplayName);
                    text = string.Concat(new string[]
                    {
                        text,
                        inventorySlot.Item.ItemDef.DisplayName,
                        " [",
                        inventorySlot.Item.ItemDef.InternalName,
                        "]",
                        Environment.NewLine
                    });
                }
            }
            XtraMessageBox.Show(text); 
#endif
        }

        private void bClear_Click(object sender, EventArgs e)
        {
#if false
            if (XtraMessageBox.Show("Are you sure to clear the filter list ?", "Delete all entry?", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                this.bindingSource.Clear();
            } 
#endif
        }

        private void bExport_Click(object sender, EventArgs e)
        {
#if false
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.InitialDirectory = Directories.SettingsPath;
            saveFileDialog.DefaultExt = "xml";
            saveFileDialog.Filter = this.itemFilterCoreType.ToString() + " filter profile (*.xml)|*.xml";
            saveFileDialog.FileName = this.itemFilterCoreType.ToString() + "Filters.xml";
            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                Astral.Functions.XmlSerializer.Serialize(saveFileDialog.FileName, this.Filter, 0);
            } 
#endif
        }

        private void bImport_Click(object sender, EventArgs e)
        {
#if false
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.InitialDirectory = Directories.SettingsPath;
            openFileDialog.DefaultExt = "xml";
            openFileDialog.Filter = this.itemFilterCoreType.ToString() + " filter profile (*.xml)|*.xml";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                ItemFilterCore itemFilterCore = Astral.Functions.XmlSerializer.Deserialize<ItemFilterCore>(openFileDialog.FileName, false, 0);
                if (itemFilterCore.Entries.Count > 0)
                {
                    DialogResult dialogResult = DialogResult.Abort;
                    if (this.Filter.Entries.Count > 0)
                    {
                        dialogResult = XtraMessageBox.Show("Add to current list ? (Else, clear it before)", "Import filters", MessageBoxButtons.YesNoCancel);
                    }
                    if (dialogResult == DialogResult.Cancel)
                    {
                        return;
                    }
                    if (this.Filter.Entries.Count != 0)
                    {
                        if (dialogResult != DialogResult.Yes)
                        {
                            this.bindingSource.Clear();
                            using (List<ItemFilterEntry>.Enumerator enumerator = itemFilterCore.Entries.GetEnumerator())
                            {
                                while (enumerator.MoveNext())
                                {
                                    ItemFilterEntry itemFilterEntry_ = enumerator.Current;
                                    this.method_AddItemFilterEntry(itemFilterEntry_);
                                }
                                return;
                            }
                        }
                    }
                    using (List<ItemFilterEntry>.Enumerator enumerator = itemFilterCore.Entries.GetEnumerator())
                    {
                        while (enumerator.MoveNext())
                        {
                            ItemFilterEntry itemFilterEntry_2 = enumerator.Current;
                            this.method_AddItemFilterEntry(itemFilterEntry_2);
                        }
                        return;
                    }
                }
                XtraMessageBox.Show("Empty or file opening error.");
            } 
#endif
        }

        private void itemListCombo_EditValueChanging(object sender, ChangingEventArgs e)
        {
#if false
            string text = e.NewValue.ToString();
            if (text.Contains('['))
            {
                if (this.btnReverse.Checked)
                {
                    int num = text.IndexOf(']');
                    if (num > 1)
                    {
                        string newValue = text.Remove(0, num + 2);
                        e.NewValue = newValue;
                        return;
                    }
                }
                else
                {
                    int num2 = text.IndexOf('[');
                    if (num2 > 1)
                    {
                        string newValue2 = text.Remove(num2 - 1);
                        e.NewValue = newValue2;
                    }
                }
            } 
#endif
        }

        private void bntSave_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.OK;
            Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }
    }
}
