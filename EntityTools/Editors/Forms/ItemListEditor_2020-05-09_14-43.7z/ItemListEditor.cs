﻿using Astral.Classes.ItemFilter;
using Astral.Controllers;
using DevExpress.XtraBars;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Controls;
using DevExpress.XtraEditors.Repository;
using EntityTools.Tools.BuySellItems;
using MyNW.Classes;
using MyNW.Internals;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace EntityTools.Editors
{
    public partial class ItemListEditor : Form
    {
        BindingList<ItemFilterEntryExt> filter = new BindingList<ItemFilterEntryExt>();
        
        public ItemListEditor()
        {
            InitializeComponent();

            RepositoryItemComboBox repositoryItemComboBox = new RepositoryItemComboBox();
            repositoryItemComboBox.QueryPopUp += this.method_0;
            repositoryItemComboBox.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
            this.bReverse.Visible = false;
            this.colFilterType.ColumnEdit = repositoryItemComboBox;
        }

        private void method_0(object sender, CancelEventArgs e)
        {
            ComboBoxEdit comboBoxEdit = sender as ComboBoxEdit;
            comboBoxEdit.Properties.Items.Clear();
            foreach (ItemFilterType itemFilterType in ItemFilterCore.smethod_0(this.Type))
            {
                comboBoxEdit.Properties.Items.Add(itemFilterType);
            }
        }

        public ItemFilterCoreType Type
        {
            get
            {
                return this.itemFilterCoreType_0;
            }
            set
            {
                this.itemFilterCoreType_0 = value;
                this.bReverse.Visible = (value == ItemFilterCoreType.ItemsID);
                ItemFilterCoreType itemFilterCoreType = this.itemFilterCoreType_0;
                if (itemFilterCoreType == ItemFilterCoreType.Items)
                {
                    this.addTypeLabel.Text = "Add item :";
                    return;
                }
                if (itemFilterCoreType != ItemFilterCoreType.Loots)
                {
                    return;
                }
                this.addTypeLabel.Text = "Add loot :";
            }
        }

        private void ItemFilterUC_Load(object sender, EventArgs e)
        {
        }

        private void bRemoveEntry_Click(object sender, EventArgs e)
        {
            if (this.bindingSource.Current != null && Class81.smethod_0("Are you sure to delete this entry ?", null))
            {
                this.bindingSource.RemoveCurrent();
            }
        }

        [Browsable(false)]
        public ItemFilterCore Filter
        {
            get
            {
                return this.itemFilterCore_0;
            }
            set
            {
                this.itemFilterCore_0 = value;
                if (value != null)
                {
                    this.bindingSource.DataSource = value.Entries;
                    return;
                }
                this.bindingSource.DataSource = null;
            }
        }

        private void method_1(object sender, EventArgs e)
        {
        }

        private void barButtonItem1_ItemClick(object sender, ItemClickEventArgs e)
        {
        }

        private void itemListCombo_QueryPopUp(object sender, CancelEventArgs e)
        {
            this.itemListCombo.Properties.Items.Clear();
            switch (this.itemFilterCoreType_0)
            {
                case ItemFilterCoreType.Items:
                    this.itemListCombo.Properties.Items.AddRange(ItemFilterCore.smethod_2(ItemFilterType.ItemName, false).Values);
                    return;
                case ItemFilterCoreType.Loots:
                    this.itemListCombo.Properties.Items.AddRange(ItemFilterCore.smethod_2(ItemFilterType.Loot, false).Values);
                    return;
                case ItemFilterCoreType.ItemsID:
                    this.itemListCombo.Properties.Items.AddRange(ItemFilterCore.smethod_2(ItemFilterType.ItemID, this.bReverse.Checked).Values);
                    return;
                default:
                    return;
            }
        }

        private void bAddEntryAdvanced_Click(object sender, EventArgs e)
        {
            this.addEntryPop.HidePopup();
            ItemFilterEntry itemFilterEntry = ItemFilterAddEntry.smethod_0(this.itemFilterCoreType_0);
            if (itemFilterEntry != null)
            {
                this.bindingSource.Add(itemFilterEntry);
                this.bindingSource.Position = this.bindingSource.IndexOf(itemFilterEntry);
            }
        }

        public void method_2(ItemFilterEntry itemFilterEntry_0)
        {
            if (itemFilterEntry_0 != null)
            {
                this.bindingSource.Add(itemFilterEntry_0);
                this.bindingSource.Position = this.bindingSource.IndexOf(itemFilterEntry_0);
            }
        }

        public void method_3()
        {
            this.bindingSource.Clear();
        }

        private void bAddItem_Click(object sender, EventArgs e)
        {
            string text = this.itemListCombo.Text;
            if (text.Length > 0)
            {
                ItemFilterEntry itemFilterEntry = new ItemFilterEntry
                {
                    Text = text
                };
                switch (this.Type)
                {
                    case ItemFilterCoreType.Items:
                        itemFilterEntry.Type = ItemFilterType.ItemName;
                        break;
                    case ItemFilterCoreType.Loots:
                        itemFilterEntry.Type = ItemFilterType.Loot;
                        break;
                    case ItemFilterCoreType.ItemsID:
                        itemFilterEntry.Type = ItemFilterType.ItemID;
                        break;
                }
                this.method_2(itemFilterEntry);
                return;
            }
            XtraMessageBox.Show("Item name is empty !");
        }

        // Token: 0x06001E98 RID: 7832 RVA: 0x000A6F3C File Offset: 0x000A513C
        private void bShowItems_Click(object sender, EventArgs e)
        {
            string text = string.Empty;
            List<string> list = new List<string>();
            foreach (InventorySlot inventorySlot in EntityManager.LocalPlayer.AllItems)
            {
                if (!list.Contains(inventorySlot.Item.ItemDef.DisplayName) && this.Filter.method_0(inventorySlot.Item))
                {
                    list.Add(inventorySlot.Item.ItemDef.DisplayName);
                    text = string.Concat(new string[]
                    {
                        text,
                        inventorySlot.Item.ItemDef.DisplayName,
                        " [",
                        inventorySlot.Item.ItemDef.InternalName,
                        "]",
                        Environment.NewLine
                    });
                }
            }
            XtraMessageBox.Show(text);
        }

        private void bClear_Click(object sender, EventArgs e)
        {
            if (Class81.smethod_0("Are you sure to clear the filter list ?", null))
            {
                this.method_3();
            }
        }

        // Token: 0x06001E9A RID: 7834 RVA: 0x000A7038 File Offset: 0x000A5238
        private void bExport_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.InitialDirectory = Directories.SettingsPath;
            saveFileDialog.DefaultExt = "xml";
            saveFileDialog.Filter = this.itemFilterCoreType_0.ToString() + " filter profile (*.xml)|*.xml";
            saveFileDialog.FileName = this.itemFilterCoreType_0.ToString() + "Filters.xml";
            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                Astral.Functions.XmlSerializer.Serialize(saveFileDialog.FileName, this.Filter, 0);
            }
        }

        // Token: 0x06001E9B RID: 7835 RVA: 0x000A70C0 File Offset: 0x000A52C0
        private void bImport_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.InitialDirectory = Directories.SettingsPath;
            openFileDialog.DefaultExt = "xml";
            openFileDialog.Filter = this.itemFilterCoreType_0.ToString() + " filter profile (*.xml)|*.xml";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                ItemFilterCore itemFilterCore = Astral.Functions.XmlSerializer.Deserialize<ItemFilterCore>(openFileDialog.FileName, false, 0);
                if (itemFilterCore.Entries.Count > 0)
                {
                    DialogResult dialogResult = DialogResult.Abort;
                    if (this.Filter.Entries.Count > 0)
                    {
                        dialogResult = XtraMessageBox.Show("Add to current list ? (Else, clear it before)", "Import filters", MessageBoxButtons.YesNoCancel);
                    }
                    if (dialogResult == DialogResult.Cancel)
                    {
                        return;
                    }
                    if (this.Filter.Entries.Count != 0)
                    {
                        if (dialogResult != DialogResult.Yes)
                        {
                            this.method_3();
                            using (List<ItemFilterEntry>.Enumerator enumerator = itemFilterCore.Entries.GetEnumerator())
                            {
                                while (enumerator.MoveNext())
                                {
                                    ItemFilterEntry itemFilterEntry_ = enumerator.Current;
                                    this.method_2(itemFilterEntry_);
                                }
                                return;
                            }
                        }
                    }
                    using (List<ItemFilterEntry>.Enumerator enumerator = itemFilterCore.Entries.GetEnumerator())
                    {
                        while (enumerator.MoveNext())
                        {
                            ItemFilterEntry itemFilterEntry_2 = enumerator.Current;
                            this.method_2(itemFilterEntry_2);
                        }
                        return;
                    }
                }
                XtraMessageBox.Show("Empty or file opening error.");
            }
        }

        private void itemListCombo_EditValueChanging(object sender, ChangingEventArgs e)
        {
            string text = e.NewValue.ToString();
            if (text.Contains('['))
            {
                if (this.bReverse.Checked)
                {
                    int num = text.IndexOf(']');
                    if (num > 1)
                    {
                        string newValue = text.Remove(0, num + 2);
                        e.NewValue = newValue;
                        return;
                    }
                }
                else
                {
                    int num2 = text.IndexOf('[');
                    if (num2 > 1)
                    {
                        string newValue2 = text.Remove(num2 - 1);
                        e.NewValue = newValue2;
                    }
                }
            }
        }

        public bool ShowExpand
        {
            get
            {
                return this.bExpand.Visible;
            }
            set
            {
                this.bExpand.Visible = value;
            }
        }

        private void bExpand_Click(object sender, EventArgs e)
        {
            ItemFilterForm.smethod_0(this.Filter, this.itemFilterCoreType_0);
            this.bindingSource.ResetBindings(true);
        }

        private void addEntryMenu_BeforePopup(object sender, CancelEventArgs e)
        {
        }

        private void addEntryMenu_Popup(object sender, EventArgs e)
        {
        }
    }
}
